
import funksiyalar as f

print("Keling o'ylagan sonni topish o'ynaymiz!")
f.play(10)